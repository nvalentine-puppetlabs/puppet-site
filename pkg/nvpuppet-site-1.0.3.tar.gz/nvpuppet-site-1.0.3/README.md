puppet-site
-----------
This is the site module. It is meant to act as scaffolding for quick
creation (perhaps via git clone w/o .git) of a module containing 
site-specific Puppet code following the "Roles and Profiles" convention 
described by Craig Dunn at:

http://www.craigdunn.org/2012/05/239/

# License
Apache 2.0 - http://www.apache.org/licenses/LICENSE-2.0.txt

# Contact
Nathan Valentine - nathan@puppetlabs.com

# Support
See Contact.
